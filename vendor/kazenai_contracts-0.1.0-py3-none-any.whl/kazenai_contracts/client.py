from __future__ import annotations

import json
import urllib.request
from dataclasses import asdict
from typing import Any, Dict

from .types import EntitlementCheckRequest, EntitlementDecision


class KazenAIPlatformClient:
    def __init__(self, base_url: str, token: str) -> None:
        self.base_url = base_url.rstrip("/")
        self.token = token

    def _headers(self) -> Dict[str, str]:
        headers = {"Content-Type": "application/json"}
        if self.token.count(".") == 2:
            headers["Authorization"] = f"Bearer {self.token}"
        else:
            headers["X-API-Key"] = self.token
        return headers

    def _request(self, path: str, payload: Dict[str, Any]) -> Dict[str, Any]:
        req = urllib.request.Request(
            f"{self.base_url}{path}",
            data=json.dumps(payload).encode("utf-8"),
            headers=self._headers(),
            method="POST",
        )
        try:
            with urllib.request.urlopen(req, timeout=30) as res:
                return json.loads(res.read().decode("utf-8"))
        except urllib.error.HTTPError as exc:
            body = json.loads(exc.read().decode("utf-8") or "{}")
            if exc.code == 402:
                return body
            raise

    def check_entitlement(self, body: EntitlementCheckRequest) -> EntitlementDecision:
        payload = self._request("/v1/entitlements/check", asdict(body))
        return EntitlementDecision(**payload)

    def record_usage(self, payload: Dict[str, Any]) -> None:
        self._request("/v1/usage/events", payload)
