"""Canonical KazenAI service URL resolution."""

from __future__ import annotations

import os
from functools import lru_cache
from pathlib import Path
from typing import Dict

try:
    import yaml  # type: ignore
except ImportError:
    yaml = None  # type: ignore

_ENV_MAP = {
    "lens": "KAZENAI_LENS_URL",
    "finops": "KAZENAI_FINOPS_URL",
    "brain": "KAZENAI_BRAIN_URL",
    "builder": "KAZENAI_BUILDER_URL",
    "founder_os": "KAZENAI_FOUNDER_OS_URL",
    "platform": "KAZENAI_PLATFORM_URL",
    "growthops": "KAZENAI_GROWTHOPS_URL",
    "gateway": "KAZENAI_GATEWAY_URL",
    "auth": "KAZENAI_AUTH_URL",
    "home": "KAZENAI_HOME_URL",
}

# Deprecated logical-name aliases (old → new), accepted so callers using the
# previous name keep resolving during the orchestrator→builder rename.
_DEPRECATED_NAME_ALIASES = {"orchestrator": "builder"}

# Deprecated env var fallbacks (new var → old var), consulted when the new var
# is unset so in-flight deploys that still set the old name keep working.
_DEPRECATED_ENV_ALIASES = {"KAZENAI_BUILDER_URL": "KAZENAI_ORCHESTRATOR_URL"}


@lru_cache(maxsize=1)
def _load_defaults() -> Dict[str, str]:
    path = Path(__file__).resolve().parents[2] / "config" / "service_defaults.yaml"
    if yaml is None or not path.is_file():
        return {
            "lens": "http://localhost:8780",
            "finops": "http://localhost:8090",
            "brain": "http://localhost:8790",
            "builder": "http://localhost:8000",
            "founder_os": "http://localhost:8800",
            "platform": "http://localhost:4100",
            "growthops": "http://localhost:8810",
        }
    data = yaml.safe_load(path.read_text(encoding="utf-8")) or {}
    return {str(k): str(v).rstrip("/") for k, v in data.items()}


def service_url(name: str, *, default: str | None = None) -> str:
    """Resolve a service base URL by logical name."""
    name = _DEPRECATED_NAME_ALIASES.get(name, name)
    env_key = _ENV_MAP.get(name)
    if env_key:
        raw = os.getenv(env_key, "").strip()
        if not raw and env_key in _DEPRECATED_ENV_ALIASES:
            raw = os.getenv(_DEPRECATED_ENV_ALIASES[env_key], "").strip()
        if raw:
            return raw.rstrip("/")
    defaults = _load_defaults()
    if name in defaults:
        return defaults[name]
    if default is not None:
        return default.rstrip("/")
    raise KeyError(f"Unknown service URL: {name}")
