from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional


@dataclass
class Delegation:
    kind: str = "none"
    asserted_org_id: Optional[str] = None
    asserted_actor_id: Optional[str] = None
    audience: Optional[str] = None
    scope: List[str] = field(default_factory=list)


@dataclass
class Principal:
    """Canonical Control principal (FINAL_1 P1-1).

    ``user_id`` remains for backward compatibility; prefer ``subject_id`` /
    ``actor_id``. For humans without delegation, subject_id == actor_id.
    """

    role: str
    auth_type: str
    identity_kind: str = "human"
    subject_id: Optional[str] = None
    actor_id: Optional[str] = None
    user_id: Optional[str] = None
    org_id: Optional[str] = None
    workspace_id: Optional[str] = None
    authorized_org_ids: Optional[List[str]] = None
    authorized_workspace_ids: Optional[List[str]] = None
    delegation: Optional[Delegation] = None


@dataclass
class EntitlementCheckRequest:
    org_id: str
    subject: str
    workspace_id: Optional[str] = None
    quantity: int = 1
    estimated_cost_cents: int = 0


@dataclass
class EntitlementDecision:
    allowed: bool
    decision: str
    plan_id: Optional[str] = None
    reason: Optional[str] = None
    limits: Optional[Dict[str, Any]] = None
    usage: Optional[Dict[str, Any]] = None
