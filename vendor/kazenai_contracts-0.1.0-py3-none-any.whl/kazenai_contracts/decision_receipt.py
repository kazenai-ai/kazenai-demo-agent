"""Economic decision receipt helpers (FINAL_1_b P2-1).

Append-only facts. Corrections link via correction_of_decision_id.
"""

from __future__ import annotations

from datetime import datetime, timezone
from typing import Any, Mapping, Optional, Sequence
from uuid import uuid4

RECEIPT_VERSION = "economic-decision-receipt.v1"

REASON_CODES = frozenset(
    {
        "allowed_with_reservation",
        "policy_denied",
        "insufficient_capacity",
        "unsupported_estimate_or_mode",
        "authority_unavailable",
        "invalid_attribution",
        "invalid_identity",
        "duplicate_idempotent_replay",
        "idempotency_payload_mismatch",
        "entitlement_stale_or_missing",
        "provider_outcome_unknown",
        "pending_reconciliation",
    }
)

DECISIONS = frozenset({"allow", "deny", "degraded"})

# Map legacy AdmitError codes → receipt reason_code.
ERROR_CODE_TO_REASON = {
    "invalid_amount": "insufficient_capacity",
    "unsupported_mode": "unsupported_estimate_or_mode",
    "sql_unavailable": "authority_unavailable",
    "unauthorized": "invalid_identity",
    "cross_tenant": "invalid_identity",
    "conflict": "idempotency_payload_mismatch",
    "idempotency_payload_mismatch": "idempotency_payload_mismatch",
    "invalid_attribution": "invalid_attribution",
    "invalid_identity": "invalid_identity",
    "policy_denied": "policy_denied",
}


class ReceiptContractError(ValueError):
    def __init__(self, code: str, message: str) -> None:
        super().__init__(message)
        self.code = code
        self.message = message


def _utc_z(dt: Optional[datetime] = None) -> str:
    d = dt or datetime.now(timezone.utc)
    return d.astimezone(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")


def human_summary(receipt: Mapping[str, Any]) -> str:
    """Derived human text — not the contract."""
    decision = receipt.get("decision")
    reason = receipt.get("reason_code")
    constraint = (receipt.get("determining_constraint") or {}).get("detail") or ""
    base = f"Decision={decision}; reason={reason}."
    return f"{base} {constraint}".strip() if constraint else base


def build_decision_receipt(
    *,
    decision: str,
    reason_code: str,
    org_id: str,
    workspace_id: str,
    requested_estimate_usd_micros: int,
    economics: Optional[Mapping[str, Any]] = None,
    execution: Optional[Mapping[str, Any]] = None,
    evaluated_policies: Optional[Sequence[Mapping[str, Any]]] = None,
    determining_constraint: Optional[Mapping[str, Any]] = None,
    reserved_usd_micros: Optional[int] = None,
    remaining_capacity_usd_micros: Optional[int] = None,
    reservation_id: Optional[str] = None,
    reservation_state: Optional[str] = None,
    pricing_version: str = "",
    estimator_version: str = "pre_call_estimate.v1",
    cost_confidence: str = "estimate",
    principal_ref: str = "",
    entitlement_snapshot: Optional[Mapping[str, Any]] = None,
    expires_utc: Optional[str] = None,
    decision_id: Optional[str] = None,
    correction_of_decision_id: Optional[str] = None,
    request_utc: Optional[str] = None,
    decision_utc: Optional[str] = None,
) -> dict[str, Any]:
    if decision not in DECISIONS:
        raise ReceiptContractError("invalid_receipt", f"unknown decision {decision!r}")
    if reason_code not in REASON_CODES:
        raise ReceiptContractError("invalid_receipt", f"unknown reason_code {reason_code!r}")
    if not org_id or not workspace_id:
        raise ReceiptContractError("invalid_identity", "org_id and workspace_id required")

    econ = dict(economics or {"attribution_state": "unattributed"})
    if "attribution_state" not in econ:
        econ["attribution_state"] = "unattributed"

    constraint = dict(
        determining_constraint
        or {
            "scope": "workspace",
            "outcome": decision,
            "detail": reason_code,
        }
    )

    receipt: dict[str, Any] = {
        "receipt_version": RECEIPT_VERSION,
        "decision_id": decision_id or f"dec_{uuid4().hex}",
        "decision": decision,
        "reason_code": reason_code,
        "authority": {
            "org_id": org_id,
            "workspace_id": workspace_id,
            **({"principal_ref": principal_ref} if principal_ref else {}),
        },
        "economics": econ,
        "execution": dict(execution or {}),
        "evaluated_policies": [dict(p) for p in (evaluated_policies or [])],
        "determining_constraint": constraint,
        "requested_estimate_usd_micros": int(requested_estimate_usd_micros),
        "reserved_usd_micros": reserved_usd_micros,
        "remaining_capacity_usd_micros": remaining_capacity_usd_micros,
        "currency": "USD",
        "precision": "micro",
        "pricing_version": pricing_version or "",
        "estimator_version": estimator_version,
        "cost_confidence": cost_confidence,
        "reservation_id": reservation_id,
        "reservation_state": reservation_state,
        "entitlement_snapshot": dict(entitlement_snapshot) if entitlement_snapshot else None,
        "timestamps": {
            "request_utc": request_utc or _utc_z(),
            "decision_utc": decision_utc or _utc_z(),
            **({"expires_utc": expires_utc} if expires_utc else {}),
        },
        "correction_of_decision_id": correction_of_decision_id,
    }
    return receipt


def reason_from_admit_error(code: str, message: str = "") -> str:
    if "insufficient" in (message or "").lower():
        return "insufficient_capacity"
    if "no budget limits" in (message or "").lower():
        return "policy_denied"
    if "attribution" in (message or "").lower():
        return "invalid_attribution"
    return ERROR_CODE_TO_REASON.get(code, "policy_denied")
