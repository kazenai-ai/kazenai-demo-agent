"""Shared pagination helpers for KazenAI HTTP APIs."""

from __future__ import annotations

import base64
import json
from typing import Any, Callable, Dict, List, Optional, Sequence, TypeVar

DEFAULT_LIST_LIMIT = 50
MAX_LIST_LIMIT = 200
DEFAULT_EVENT_LIMIT = 50
MAX_EVENT_LIMIT = 500
MAX_EVENT_SLICE_LIMIT = 5000
MAX_INGEST_BATCH = 500
MAX_INGEST_BODY_BYTES = 1_048_576

T = TypeVar("T")


def clamp_limit(value: int, *, default: int = DEFAULT_LIST_LIMIT, maximum: int = MAX_LIST_LIMIT) -> int:
    try:
        n = int(value)
    except (TypeError, ValueError):
        n = default
    if n < 1:
        n = default
    return min(n, maximum)


def encode_cursor(payload: Dict[str, Any]) -> str:
    raw = json.dumps(payload, separators=(",", ":"), sort_keys=True).encode("utf-8")
    return base64.urlsafe_b64encode(raw).decode("ascii").rstrip("=")


def decode_cursor(cursor: Optional[str]) -> Dict[str, Any]:
    if not cursor:
        return {}
    pad = "=" * (-len(cursor) % 4)
    try:
        data = json.loads(base64.urlsafe_b64decode(cursor + pad).decode("utf-8"))
    except Exception:
        return {}
    return data if isinstance(data, dict) else {}


def paginate_sequence(
    rows: Sequence[T],
    *,
    limit: int,
    cursor: Optional[str] = None,
    cursor_getter: Callable[[T], Dict[str, Any]],
    cursor_matcher: Callable[[T, Dict[str, Any]], bool],
) -> Dict[str, Any]:
    """Slice an in-memory sequence after an opaque cursor."""
    capped = clamp_limit(limit)
    cur = decode_cursor(cursor)
    started = not cur
    page: List[T] = []
    for row in rows:
        if not started:
            if cursor_matcher(row, cur):
                started = True
            continue
        page.append(row)
        if len(page) > capped:
            break
    has_more = len(page) > capped
    if has_more:
        page = page[:capped]
    next_cursor = None
    if has_more and page:
        next_cursor = encode_cursor(cursor_getter(page[-1]))
    return {
        "items": list(page),
        "pagination": {
            "limit": capped,
            "has_more": has_more,
            "next_cursor": next_cursor,
        },
    }


def pagination_meta(*, limit: int, has_more: bool, next_cursor: Optional[str] = None) -> Dict[str, Any]:
    return {"limit": limit, "has_more": has_more, "next_cursor": next_cursor if has_more else None}
