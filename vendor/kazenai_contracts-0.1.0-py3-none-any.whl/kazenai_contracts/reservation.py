"""Reservation lifecycle contract helpers (FINAL_1 P2-1).

Pure specification logic — not the FinOps runtime engine.
"""

from __future__ import annotations

import math
from decimal import Decimal, ROUND_CEILING, ROUND_HALF_UP
from typing import Any, Mapping, Optional

LIFECYCLE_VERSION = "reservation.lifecycle.v1"
USD_MICROS_SCALE = 1_000_000
SAFE_INTEGER_MAX = 9_007_199_254_740_991

STATES = frozenset(
    {
        "new",
        "reserved",
        "in_flight",
        "settled",
        "cancelled_before_call",
        "pending_reconciliation",
    }
)

# (from_state, event) -> to_state
TRANSITIONS: dict[tuple[str, str], str] = {
    ("new", "admit"): "reserved",
    ("reserved", "provider_started"): "in_flight",
    ("reserved", "cancel_before_call"): "cancelled_before_call",
    ("in_flight", "usage_known"): "settled",
    ("in_flight", "outcome_unknown"): "pending_reconciliation",
    ("pending_reconciliation", "usage_known"): "settled",
    ("pending_reconciliation", "replay_pending"): "pending_reconciliation",
}

TERMINAL = frozenset({"settled", "cancelled_before_call"})


class ReservationContractError(ValueError):
    """Lifecycle contract violation."""

    def __init__(self, code: str, message: str) -> None:
        super().__init__(message)
        self.code = code
        self.message = message


def assert_safe_integer(value: int, *, field: str = "amount") -> int:
    if not isinstance(value, int) or isinstance(value, bool):
        raise ReservationContractError("invalid_amount", f"{field} must be an int")
    if abs(value) > SAFE_INTEGER_MAX:
        raise ReservationContractError("overflow", f"{field} exceeds safe integer range")
    return value


def usd_to_micros_ceil(amount: Decimal | float | str | int) -> int:
    """Convert USD to micro-USD with ceiling (reservations / conservative debits)."""
    d = Decimal(str(amount))
    if not d.is_finite():
        raise ReservationContractError("invalid_amount", "nonfinite USD amount")
    if d < 0:
        raise ReservationContractError("invalid_amount", "negative USD input not allowed")
    micros = (d * Decimal(USD_MICROS_SCALE)).to_integral_value(rounding=ROUND_CEILING)
    return assert_safe_integer(int(micros), field="usd_micros")


def price_usage_to_micros(
    *,
    quantity: Decimal | float | str | int,
    unit_price_usd: Decimal | float | str,
    rounding: str = "half_up",
) -> int:
    """Compute usage × price in Decimal first, then round to micro-USD."""
    q = Decimal(str(quantity))
    p = Decimal(str(unit_price_usd))
    if not q.is_finite() or not p.is_finite():
        raise ReservationContractError("invalid_amount", "nonfinite price inputs")
    if q < 0 or p < 0:
        raise ReservationContractError("invalid_amount", "negative price inputs not allowed")
    raw = q * p * Decimal(USD_MICROS_SCALE)
    mode = ROUND_CEILING if rounding == "ceil" else ROUND_HALF_UP
    micros = raw.to_integral_value(rounding=mode)
    return assert_safe_integer(int(micros), field="usd_micros")


def validate_input_amount_micros(value: Any, *, allow_zero: bool = True) -> int:
    if isinstance(value, bool) or not isinstance(value, int):
        if isinstance(value, float):
            if not math.isfinite(value) or value != int(value):
                raise ReservationContractError("invalid_amount", "fractional or nonfinite amount")
            value = int(value)
        else:
            raise ReservationContractError("invalid_amount", "amount must be integer micro-USD")
    assert_safe_integer(value)
    if value < 0:
        raise ReservationContractError("invalid_amount", "negative input amount not allowed")
    if value == 0 and not allow_zero:
        raise ReservationContractError("invalid_amount", "amount must be > 0")
    return value


def apply_transition(state: str, event: str) -> str:
    if state not in STATES:
        raise ReservationContractError("invalid_transition", f"unknown state {state!r}")
    key = (state, event)
    if key not in TRANSITIONS:
        raise ReservationContractError(
            "invalid_transition",
            f"cannot apply {event!r} from {state!r}",
        )
    return TRANSITIONS[key]


def remaining_capacity_micros(
    *,
    limit_usd_micros: int,
    settled_billable_usd_micros: int,
    outstanding_reserved_usd_micros: int,
) -> int:
    for name, val in (
        ("limit_usd_micros", limit_usd_micros),
        ("settled_billable_usd_micros", settled_billable_usd_micros),
        ("outstanding_reserved_usd_micros", outstanding_reserved_usd_micros),
    ):
        assert_safe_integer(val, field=name)
        if val < 0:
            raise ReservationContractError("invalid_amount", f"{name} must be non-negative")
    remaining = limit_usd_micros - settled_billable_usd_micros - outstanding_reserved_usd_micros
    return assert_safe_integer(remaining, field="remaining_usd_micros")


def _material_payload(req: Mapping[str, Any]) -> dict[str, Any]:
    """Fields that must match on idempotent replay."""
    keys = (
        "call_id",
        "attempt",
        "org_id",
        "workspace_id",
        "run_id",
        "feature",
        "actor_id",
        "team",
        "estimated_usd_micros",
        "actual_usd_micros",
        "event",
        "reservation_id",
    )
    return {k: req.get(k) for k in keys if k in req}


def _payloads_conflict(stored: Mapping[str, Any], request: Mapping[str, Any]) -> bool:
    a = _material_payload(stored)
    b = _material_payload(request)
    shared = set(a) & set(b)
    if not shared:
        return False
    return any(a[k] != b[k] for k in shared)


def evaluate_fixture(fixture: Mapping[str, Any]) -> dict[str, Any]:
    """Evaluate a reservation lifecycle fixture.

    Fixture shapes:
      - transition: {from, event, expect_to | expect_error}
      - money: {op, ...}
      - idempotency: {stored, request, expect}
      - settle: {reservation, request, expect_result | expect_error}
      - stream: {profile, expect_error}
      - capacity / policy_edit / window_rollover scenarios
    """
    kind = str(fixture.get("kind") or "").strip()
    expect = fixture.get("expect")

    try:
        if kind == "transition":
            to = apply_transition(str(fixture["from"]), str(fixture["event"]))
            if expect == "reject":
                return {"ok": False, "error": {"code": "invalid_transition", "message": "expected reject"}}
            if fixture.get("expect_to") and to != fixture["expect_to"]:
                return {
                    "ok": False,
                    "error": {"code": "invalid_transition", "message": f"got {to}, want {fixture['expect_to']}"},
                }
            return {"ok": True, "to": to}

        if kind == "money":
            op = str(fixture["op"])
            if op == "usd_to_micros_ceil":
                got = usd_to_micros_ceil(fixture["usd"])
            elif op == "price_usage":
                got = price_usage_to_micros(
                    quantity=fixture["quantity"],
                    unit_price_usd=fixture["unit_price_usd"],
                    rounding=str(fixture.get("rounding") or "half_up"),
                )
            elif op == "validate_input":
                got = validate_input_amount_micros(
                    fixture["value"],
                    allow_zero=bool(fixture.get("allow_zero", True)),
                )
            elif op == "remaining":
                got = remaining_capacity_micros(
                    limit_usd_micros=int(fixture["limit_usd_micros"]),
                    settled_billable_usd_micros=int(fixture["settled_billable_usd_micros"]),
                    outstanding_reserved_usd_micros=int(fixture["outstanding_reserved_usd_micros"]),
                )
            else:
                raise ReservationContractError("invalid_amount", f"unknown money op {op}")
            if expect == "reject":
                return {"ok": False, "error": {"code": "invalid_amount", "message": "expected reject"}}
            if "expect_micros" in fixture and got != int(fixture["expect_micros"]):
                return {
                    "ok": False,
                    "error": {
                        "code": "invalid_amount",
                        "message": f"got {got}, want {fixture['expect_micros']}",
                    },
                }
            return {"ok": True, "usd_micros": got}

        if kind == "idempotency":
            stored = fixture.get("stored") or {}
            request = fixture.get("request") or {}
            if stored.get("idempotency_key") != request.get("idempotency_key"):
                raise ReservationContractError("conflict", "idempotency key mismatch")
            if stored.get("tenant_org_id") != request.get("org_id"):
                raise ReservationContractError("cross_tenant", "idempotency scoped to tenant")
            if _payloads_conflict(stored, request):
                raise ReservationContractError(
                    "idempotency_payload_mismatch",
                    "same key with different material payload",
                )
            if expect == "reject":
                return {"ok": False, "error": {"code": "conflict", "message": "expected reject"}}
            return {"ok": True, "result": "duplicate"}

        if kind == "settle":
            reservation = dict(fixture.get("reservation") or {})
            request = dict(fixture.get("request") or {})
            res_org = str((reservation.get("dimensions") or {}).get("org_id") or "")
            req_org = str(request.get("org_id") or "")
            if req_org and res_org and req_org != res_org:
                raise ReservationContractError("cross_tenant", "reservation org mismatch")
            if request.get("reservation_id") and request["reservation_id"] != reservation.get(
                "reservation_id"
            ):
                raise ReservationContractError("reservation_not_found", "reservation_id mismatch")
            if request.get("call_id") and request["call_id"] != reservation.get("call_id"):
                raise ReservationContractError("conflict", "call_id mismatch")
            if request.get("attempt") is not None and int(request["attempt"]) != int(
                reservation.get("attempt") or 0
            ):
                raise ReservationContractError("conflict", "attempt mismatch")

            event = str(request.get("event") or "")
            state = str(reservation.get("state") or "")
            # Policy edits must never erase outstanding exposure (G04).
            if fixture.get("policy_edit_resets_exposure"):
                raise ReservationContractError(
                    "invalid_transition",
                    "policy edit must not erase outstanding exposure",
                )
            # Settle against original window bindings only.
            if fixture.get("require_original_window"):
                req_window = request.get("window_id")
                if req_window and req_window != (reservation.get("window") or {}).get("window_id"):
                    raise ReservationContractError(
                        "invalid_transition",
                        "must settle against original window binding",
                    )

            if event == "usage_known":
                validate_input_amount_micros(request.get("actual_usd_micros"), allow_zero=True)

            # Identical settle replay
            if reservation.get("settle_result") == "applied" and event == "usage_known":
                if state == "settled" and not _payloads_conflict(
                    reservation.get("last_settle") or {}, request
                ):
                    return {
                        "ok": True,
                        "result": "duplicate",
                        "state": "settled",
                        "lifecycle_version": LIFECYCLE_VERSION,
                    }

            if state == "pending_reconciliation" and event == "replay_pending":
                return {
                    "ok": True,
                    "result": "pending",
                    "state": "pending_reconciliation",
                    "lifecycle_version": LIFECYCLE_VERSION,
                }

            new_state = apply_transition(state, event)
            result = "pending" if new_state == "pending_reconciliation" else "applied"
            if expect == "reject":
                return {"ok": False, "error": {"code": "invalid_transition", "message": "expected reject"}}
            want = fixture.get("expect_result")
            if want and result != want:
                return {
                    "ok": False,
                    "error": {"code": "conflict", "message": f"got result {result}, want {want}"},
                }
            return {
                "ok": True,
                "result": result,
                "state": new_state,
                "lifecycle_version": LIFECYCLE_VERSION,
                "reservation_id": reservation.get("reservation_id"),
            }

        if kind == "stream":
            profile = str(fixture.get("profile") or "")
            if profile == "control":
                if expect == "reject" or fixture.get("expect_error") == "unsupported_mode":
                    return {
                        "ok": True,
                        "error": {"code": "unsupported_mode", "message": "streaming disabled in Control"},
                        "mutated": False,
                    }
                raise ReservationContractError("unsupported_mode", "streaming disabled in Control")
            return {"ok": True, "mutated": False, "note": "non-control profile deferred"}

        if kind == "admit":
            limit = int(fixture["limit_usd_micros"])
            settled = int(fixture.get("settled_billable_usd_micros") or 0)
            outstanding = int(fixture.get("outstanding_reserved_usd_micros") or 0)
            estimate = validate_input_amount_micros(fixture["estimated_usd_micros"])
            remaining = remaining_capacity_micros(
                limit_usd_micros=limit,
                settled_billable_usd_micros=settled,
                outstanding_reserved_usd_micros=outstanding,
            )
            if estimate > remaining:
                raise ReservationContractError("invalid_amount", "insufficient remaining capacity")
            if fixture.get("sql_unavailable"):
                raise ReservationContractError("sql_unavailable", "deny new spending")
            return {
                "ok": True,
                "state": "reserved",
                "reserved_usd_micros": estimate,
                "lifecycle_version": LIFECYCLE_VERSION,
            }

        raise ReservationContractError("conflict", f"unknown fixture kind {kind!r}")

    except ReservationContractError as exc:
        if expect in {"reject", "error"} or fixture.get("expect_error"):
            want = fixture.get("expect_error") or fixture.get("expect_code")
            if want and want != exc.code:
                return {
                    "ok": False,
                    "error": {"code": exc.code, "message": f"got {exc.code}, want {want}"},
                }
            return {"ok": True, "error": {"code": exc.code, "message": exc.message}}
        return {"ok": False, "error": {"code": exc.code, "message": exc.message}}
