"""Business attribution contract helpers (FINAL_1_b P1-1).

Separates access-control authority from opaque economic references.
Pure validation — not the FinOps runtime engine.
"""

from __future__ import annotations

import re
from typing import Any, Mapping, Optional

ATTRIBUTION_VERSION = "business.attribution.v1"

OPAQUE_REF_RE = re.compile(r"^[A-Za-z0-9][A-Za-z0-9._:@-]{0,127}$")
STABLE_ID_RE = re.compile(r"^[a-z0-9][a-z0-9._-]{0,127}$")
ATTRIBUTION_STATES = frozenset({"attributed", "unknown", "unattributed"})

# Sentinel values that must never be treated as a real customer.
FORBIDDEN_SUBJECT_COLLAPSE = frozenset(
    {
        "",
        "unknown",
        "unattributed",
        "null",
        "none",
        "default",
        "_default",
        "anonymous",
    }
)


class AttributionContractError(ValueError):
    def __init__(self, code: str, message: str) -> None:
        super().__init__(message)
        self.code = code
        self.message = message


def validate_opaque_ref(value: Any, *, field: str) -> str:
    if not isinstance(value, str) or not value:
        raise AttributionContractError("invalid_attribution", f"{field} must be a non-empty string")
    if len(value) > 128:
        raise AttributionContractError("invalid_attribution", f"{field} exceeds 128 characters")
    if not OPAQUE_REF_RE.match(value):
        raise AttributionContractError("invalid_attribution", f"{field} has invalid characters")
    if value.lower() in FORBIDDEN_SUBJECT_COLLAPSE:
        raise AttributionContractError(
            "invalid_attribution",
            f"{field} must not collapse unknown/unattributed into a real subject token",
        )
    return value


def validate_stable_id(value: Any, *, field: str) -> str:
    if not isinstance(value, str) or not value:
        raise AttributionContractError("invalid_attribution", f"{field} must be a non-empty string")
    if len(value) > 128:
        raise AttributionContractError("invalid_attribution", f"{field} exceeds 128 characters")
    if not STABLE_ID_RE.match(value):
        raise AttributionContractError("invalid_attribution", f"{field} must be a stable lowercase id")
    return value


def resolve_attribution_state(
    *,
    business_subject_ref: Optional[str],
    feature_id: Optional[str],
    workflow_id: Optional[str],
    explicit_state: Optional[str] = None,
) -> str:
    if explicit_state is not None:
        if explicit_state not in ATTRIBUTION_STATES:
            raise AttributionContractError("invalid_attribution", f"unknown attribution_state {explicit_state!r}")
        if explicit_state == "attributed" and not business_subject_ref:
            raise AttributionContractError(
                "invalid_attribution",
                "attribution_state=attributed requires business_subject_ref",
            )
        return explicit_state
    if business_subject_ref:
        return "attributed"
    if feature_id or workflow_id:
        return "unknown"
    return "unattributed"


def build_attribution_snapshot(
    *,
    org_id: str,
    workspace_id: str,
    business_subject_ref: Optional[str] = None,
    feature_id: Optional[str] = None,
    workflow_id: Optional[str] = None,
    attribution_state: Optional[str] = None,
    run_id: str = "",
    operation_id: str = "",
    attempt_id: str = "",
    call_id: str = "",
    attempt: int = 1,
    trace_id: str = "",
    principal_ref: str = "",
    policy_version: str = "",
    pricing_version: str = "",
    reservation_id: str = "",
    decision_id: str = "",
) -> dict[str, Any]:
    if not org_id or not workspace_id:
        raise AttributionContractError("invalid_identity", "org_id and workspace_id are required")
    if business_subject_ref is not None:
        business_subject_ref = validate_opaque_ref(business_subject_ref, field="business_subject_ref")
    if feature_id is not None:
        feature_id = validate_stable_id(feature_id, field="feature_id")
    if workflow_id is not None:
        workflow_id = validate_stable_id(workflow_id, field="workflow_id")

    state = resolve_attribution_state(
        business_subject_ref=business_subject_ref,
        feature_id=feature_id,
        workflow_id=workflow_id,
        explicit_state=attribution_state,
    )

    if not operation_id:
        operation_id = call_id or "operation:unspecified"
    if not attempt_id:
        attempt_id = f"{operation_id}:attempt:{attempt}"

    return {
        "attribution_version": ATTRIBUTION_VERSION,
        "authority": {
            "org_id": org_id,
            "workspace_id": workspace_id,
            **({"principal_ref": principal_ref} if principal_ref else {}),
        },
        "economics": {
            "business_subject_ref": business_subject_ref,
            "feature_id": feature_id,
            "workflow_id": workflow_id,
            "attribution_state": state,
        },
        "execution": {
            "run_id": run_id or "",
            "operation_id": operation_id,
            "attempt_id": attempt_id,
            "call_id": call_id or "",
            "attempt": int(attempt),
            **({"trace_id": trace_id} if trace_id else {}),
        },
        "accounting": {
            **({"policy_version": policy_version} if policy_version else {}),
            **({"pricing_version": pricing_version} if pricing_version else {}),
            **({"reservation_id": reservation_id} if reservation_id else {}),
            **({"decision_id": decision_id} if decision_id else {}),
        },
    }


def assert_caller_cannot_escalate(authority: Mapping[str, Any], caller_org: str, caller_workspace: str) -> None:
    """Caller-provided attribution cannot choose another workspace or grant access."""
    if authority.get("org_id") != caller_org or authority.get("workspace_id") != caller_workspace:
        raise AttributionContractError(
            "invalid_identity",
            "attribution cannot select a different org/workspace than the authenticated principal",
        )


def material_attribution_fields(req: Mapping[str, Any]) -> dict[str, Any]:
    """Fields that must match on idempotent replay once bound to a reservation."""
    keys = (
        "org_id",
        "workspace_id",
        "business_subject_ref",
        "feature_id",
        "feature",
        "workflow_id",
        "run_id",
        "operation_id",
        "attempt_id",
        "call_id",
        "attempt",
    )
    return {k: req.get(k) for k in keys if k in req}
